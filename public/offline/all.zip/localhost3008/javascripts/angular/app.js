(function () {
    'use strict';

    angular
        .module('ex6app', ['ngRoute', 'ngCookies','ui.bootstrap'])
        .config(config)
        .run(run);

    config.$inject = ['$routeProvider', '$locationProvider'];

    function config($routeProvider, $locationProvider) {
        // confirm('config');
        $routeProvider
        // .when('/', {
        //     controller: 'HomeController',
        //     templateUrl: 'home/home.view.html',
        //     controllerAs: 'vm'
        // })
        //
            .when('/', {
                controller: 'mainCtrl',
                // templateUrl: '/temp',
                controllerAs: 'vm'
            })

            .when('/profileModal', {
                // controller: 'mainCtrl',
                // templateUrl: '/account',
                // controllerAs: 'aCtrl'
            })

            .when('/temp', {
                // controller: 'tempCtrl',
                // templateUrl: '/temp',
                //controllerAs: 'vm'
            })

            .when('/reset/:token', {
                controller: 'resetCtrl',
                templateUrl:function(routeParam){ //register it as function
                    return '/reset/' + routeParam.token;  //Get the id from the argument
                },
                controllerAs: 'vm'
            })


            // route for the home page
            .when('/home', {
                templateUrl: 'home.html',
                controller: 'mainCtrl'
            })

            // route for the about page
            .when('/about', {
                templateUrl: 'about.html',
                controller: 'aboutCtrl'
            })

            // route for the contact page
            .when('/contact', {
                templateUrl: 'contact.html',
                controller: 'contactCtrl'
            })

            .when('/loginModal', {
                // controller: 'LoginController',
                // template: "",
                // templateUrl: function () {
                //     console.log('routed /loginModal '+new Date().toTimeString())
                //     return '/temp';
                // },
                // templateUrl: '/temp',
                controllerAs: 'vm'
            })

            .when('/login', {
                // controller: 'LoginController',
                templateUrl: 'login/login.view.html',
                controllerAs: 'vm'
            })

            .when('/registerModal', {
                // controller: 'RegisterController',
                // template: "",
                // templateUrl: 'register/register.view.html',
                // controllerAs: 'vm'
            })

            .when('/register', {
                // controller: 'RegisterController',
                templateUrl: 'register/register.view.html',
                controllerAs: 'vm'
            })


            // route for the sign-up page
            .when('/logout', {
                // templateUrl: function () {
                //     confirm("???");
                //     return '/logout';
                // },
                // controller: 'LogoutController',
                // template: ""
            })

            // route for the users page
            .when('/flowers', {
                templateUrl: '/flower',
                controller: 'flowerCtrl',
                controllerAs: 'vm'
            })

            // route for the users page
            .when('/users', {
                templateUrl: '/user',
                controller: 'userCtrl',
                controllerAs: 'vm'
            })

            // route for the users page
            .when('/branches', {
                templateUrl: '/branches',
                controller: 'branchCtrl',
                controllerAs: 'vm'
            })

        // .otherwise({redirectTo: '/login'})

        ;
    }

    run.$inject = ['$rootScope', '$location', '$cookieStore', '$http', 'MenuService'];

    function run($rootScope, $location, $cookieStore, $http, MenuService) {
        // confirm('run');
        // keep user logged in after page refresh
        $rootScope.globals = $cookieStore.get('globals') || {};
        if ($rootScope.globals.currentUser) {
            $http.defaults.headers.common['Authorization'] = 'Basic ' + $rootScope.globals.currentUser.authdata; // jshint ignore:line
        }
        MenuService.initMenu();
        $rootScope.$on('$locationChangeStart', function (event, next, current) {
            // redirect to login page if not logged in and trying to access a restricted page
            var path = $location.path()
            // confirm(path);
            console.log(path);
            var restrictedPage = $.inArray($location.path(), ['/', '/login', '/register']) === -1;
            var loggedIn = $rootScope.globals.currentUser;
            // if (restrictedPage && !loggedIn) {
            //     $location.path('/login');
            // }
            angular.element('.modal').modal('hide');

        });

        // angular.element('.modal').on('click', function () {
        //     $location.path('/');
        // });
        // $('#loginModal').on('hidden.bs.modal', function (e) {
        //     $location.path('/');
        // });
        // $('#loginModal').on('shown', function () {
        //     $('body').on('click', function (e) {
        //         $location.path('/');
        //     });
        // })
        // $('#loginModal').on('hidden', function () {
        //     $('body').off('click');
        // });
        //
        // $rootScope.$on('modal.hide', function (event, reason, closed) {
        //     console.log('modal.closing: ' + (closed ? 'close' : 'dismiss') + '(' + reason + ')');
        //     var message = "You are about to leave the edit view. Uncaught reason. Are you sure?";
        //     switch (reason) {
        //         // clicked outside
        //         case "backdrop click":
        //             message = "Any changes will be lost, are you sure?";
        //             break;
        //
        //         // cancel button
        //         case "cancel":
        //             message = "Any changes will be lost, are you sure?";
        //             break;
        //
        //         // escape key
        //         case "escape key press":
        //             message = "Any changes will be lost, are you sure?";
        //             break;
        //     }
        //     if (!confirm(message)) {
        //         event.preventDefault();
        //     }
        // });
    }

})();