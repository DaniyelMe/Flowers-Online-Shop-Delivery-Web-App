(function () {
    'use strict';

    angular
        .module('companyProject')
        .controller('userCtrl', userCtrl);

    userCtrl.$inject = ['$scope', '$http', '$modal', '$log'];

    function userCtrl($scope, $http, $modal, $log) {

        var ModalInstanceCtrl, ModalInstanceCtrl2, ModalInstanceCtrl3, ModalInstanceCtrl4;

        function getUsers() {
            $http.get('/api/user/users')
                .then(function (res) {
                    $scope.users = res.data;
                    // $scope.locations = res.data;
                }, function (res) {
                    confirm('Error: ' + res.data);
                });
        }

        getUsers();

        $scope.addUser = function () {
            var modalInstance = $modal.open({
                templateUrl: '/user/editUser',
                controller: ModalInstanceCtrl4,
                resolve: {},
                scope: $scope.$new()
            });
            modalInstance.result.then(function (selectedItem) {
                console.log('selectedItem: ' + selectedItem);
                $http.post('/api/register', selectedItem)
                    .then(function (res) {
                        confirm('Success: ' + res.data);
                    }, function (res) {
                        confirm('Error: ' + res.data);
                    });
                getUsers();
            }, function () {
                console.log('Modal dismissed at: ' + new Date());
            });
        }

        $scope.editUser = function (selectedUser) {
            var editUser = selectedUser;
            console.log(editUser);
            var modalInstance = $modal.open({
                templateUrl: '/user/editUser',
                controller: ModalInstanceCtrl3,
                resolve: {
                    locations: function () {
                        return editUser;
                    }
                },
                scope: $scope.$new()
            });
            modalInstance.result.then(function (selectedItem) {
                console.log('selectedItem: ' + selectedItem);
                $http.post('/api/user/updateUser', selectedItem)
                    .then(function (res) {
                        confirm('Success: ' + res.data);
                    }, function (res) {
                        confirm('Error: ' + res.data);
                    });
                getUsers();
            }, function () {
                console.log('Modal dismissed at: ' + new Date());
            });
        }


        ModalInstanceCtrl3 = function ($scope, $modalInstance, locations) {
            // $scope.input = angular.copy(locations);
            $scope.eUsr = locations;
            console.log(locations);
            $scope.ok = function () {
                $modalInstance.close($scope.eUsr);
            };

            $scope.cancel = function () {
                $modalInstance.dismiss('cancel');
            };
        };

        ModalInstanceCtrl4 = function ($scope, $modalInstance) {
            $scope.eUsr = [];
            $scope.ok = function () {
                $modalInstance.close($scope.eUsr);
            };

            $scope.cancel = function () {
                $modalInstance.dismiss('cancel');
            };
        };

        // $scope.locations = [];

        $scope.savenewmarker = function () {
            $scope.keys.push({title: '', gps: '', desc: ''});
        };

        $scope.createmarker = function () {
            var modalInstance = $modal.open({
                templateUrl: 'modal.html',
                controller: ModalInstanceCtrl,
                resolve: {},
                scope: $scope.$new()
            });
            modalInstance.result.then(function (selectedItem) {
                $scope.locations.push({title: selectedItem.title, gps: selectedItem.gps, desc: selectedItem.desc});
            }, function () {
                console.log('Modal dismissed at: ' + new Date());
            });
        };

        $scope.editlocation = function (locations) {
            var locationToEdit = locations;
            console.log(locationToEdit);
            var modalInstance = $modal.open({
                templateUrl: '/user/editUser',
                controller: ModalInstanceCtrl2,
                resolve: {
                    locations: function () {
                        return locationToEdit;
                    }
                },
                scope: $scope.$new()
            });
            modalInstance.result.then(function (selectedItem) {
                console.log('selectedItem: ' + selectedItem.titley);

                locationToEdit.title = selectedItem.title;
                locationToEdit.gps = selectedItem.gps;
                locationToEdit.desc = selectedItem.desc;
                //$scope.locations.push({title: selectedItem.titley, gps:selectedItem.gps, desc:selectedItem.desc});
            }, function () {
                console.log('Modal dismissed at: ' + new Date());
            });
        };


        ModalInstanceCtrl = function ($scope, $modalInstance) {
            $scope.input = [];

            $scope.ok = function () {
                $modalInstance.close($scope.input);
                $scope.gps = "";
                $scope.title = "";
            };

            $scope.cancel = function () {
                $modalInstance.dismiss('cancel');
            };
        };

        ModalInstanceCtrl2 = function ($scope, $modalInstance, locations) {
            $scope.input = angular.copy(locations);
            console.log(locations);
            $scope.ok = function () {
                $modalInstance.close($scope.input);
            };

            $scope.cancel = function () {
                $modalInstance.dismiss('cancel');
            };
        };


        $scope.plotmarkers = function () {
            console.log($scope);
        };
    }
})();
//     factory('CategoryService', ['$http', function ($http) {
//         return {
//             getList: function () {
//                 return $http.get('/directory/assets/inc/category.php');
//             }
//         };
//     }])
// })();