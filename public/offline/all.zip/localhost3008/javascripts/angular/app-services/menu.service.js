(function () {
    'use strict';

    angular
        .module('ex6app')
        .factory('MenuService', MenuService);

    MenuService.$inject = ['$rootScope','$http'];
    function MenuService($rootScope, $http) {
        var service = {};

        service.initMenu = initMenu;

        initService();

        return service;

        function initMenu() {
            $http.get('/api')
                .then(function (res) {
                    $rootScope.user = res.data;
                    $rootScope.vm.user = res.data;
                }, function (res) {
                    console.log('Error: ' + res.data);
                });
        }

        function initService() {
            $rootScope.$on('$locationChangeStart', function () {
                initMenu();
            });

        }

    }

})();